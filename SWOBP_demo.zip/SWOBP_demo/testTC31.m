%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is a demo testing code for SWOBP proposed in
% 
% Tiecheng Song, Jie Feng, Shiyan Wang, Yurui Xie, ��Spatially weighted order binary
% pattern for color texture classification,�� Expert Systems with Applications, vol. 147, 
% p. 113167, 2020.
% 
% This code can only be used for research purpose. Please cite our paper if
% you read the code.
% 
% For any problem on this code, please contact with Jie Feng, fengjie_cqupt@foxmail.com
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --------------------------------------------
close all,clear all,clc
addpath('.\functions\');
load ('patternMappingu2.mat');
load('patternMappingU2_P24.mat');
load('patternMappingU2_P16.mat');

mapping=getliop('lio');

rootpic = 'J:\Color_Database\Outex-TC-00031\';
  picNum = 2720;%
  
        for i=1:picNum;
           

     filename = sprintf('%s\\images\\%06d.bmp', rootpic, i-1);
            img1 = imread(filename);
           display([num2str(i) '.... '  filename]);
   


%%%%%%%%%%%%%%%%%%%%%%%%%%  SWOBP %%%%%%%%%%%%%%%%%%%%%%%
[result1] =SWOBP(img1,1,8,'h',patternMappingu2); 
[result2] =SWOBP(img1,2,16,'h',patternMappingU2_P16); 
[result3] =SWOBP(img1,3,24,'h',patternMappingU2_P24); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             LBPhist1(i,:)=[result1]; 

         end

  trainTxt = sprintf('%s000\\train.txt', rootpic);
    testTxt = sprintf('%s000\\test.txt', rootpic);
    [trainIDs, trainClassIDs] = ReadOutexTxt(trainTxt);  
    [testIDs, testClassIDs] = ReadOutexTxt(testTxt);

        CP1 = cal_AP(LBPhist1,trainIDs, trainClassIDs,testIDs, testClassIDs)


