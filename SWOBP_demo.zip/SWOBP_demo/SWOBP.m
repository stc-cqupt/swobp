%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is the source code for SWOBP proposed in
% 
% Tiecheng Song, Jie Feng, Shiyan Wang, Yurui Xie, ��Spatially weighted order binary
% pattern for color texture classification,�� Expert Systems with Applications, vol. 147, 
% p. 113167, 2020.
% 
% This code can only be used for research purpose. Please cite our paper if
% you read the code.
% 
% For any problem on this code, please contact with Jie Feng, fengjie_cqupt@foxmail.com
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function result= SWOBP(varargin) % image,radius,neighbors,mode,mapping)
mapping=getliop('lio');


d_image=varargin{1};
mode1=varargin{4};
R=varargin{2};
P=varargin{3};
LBPmapping=varargin{5};
% threshold=varargin{6};

allchannel=double(d_image);


[F, ~, ~] = colorgradient(d_image);     %%%%gradient channel
allchannel(:,:,4)=double(F*255);
for zz=1:4        %%%%%%normalization
    imgnor=allchannel(:,:,zz);
imgnor = (imgnor-mean(imgnor(:)))/std(imgnor(:));
allchannel(:,:,zz)=imgnor;
end

[d_C,M,N,LIOP2,ou,ou_sign]=getneighbor(allchannel,R,P,mapping);
  ou_mean=mean(ou,2);

  ou2=ou<repmat(ou_mean,1,P);    %%%CDM template
  
  sign1=zeros(M*N,P);sign0=zeros(M*N,P);        %%%CDS template
  idx=find(ou_sign==1);
  sign1(idx)=sign1(idx)+1; 
  sign2=logical(ou_sign)-sign1;
  sign0=sign0+1-sign1-sign2;
sign1=sign1+sign0;


[~,orderC]=sort(d_C,2,'descend' ); 
LIOP_C = orderC(:,1)*1000 + orderC(:,2)*100 + orderC(:,3)*10+orderC(:,4); %%%% sorting
LIOP_C = mapping.table(LIOP_C)';

LIOP2=LIOP2>=repmat(LIOP_C,1,P);
LIOP2w=LIOP2.*ou2;
LIOP2w1=LIOP2.*~ou2;
mLIOP=LIOP2w;           %%%%%CDM weighting
mLIOP1=LIOP2w1;         
mLIOP3=(LIOP2).*sign1;    %%%%CDS weighting
mLIOP2=(LIOP2).*sign2;

a=allchannel(:,:,1);b=allchannel(:,:,2);c=allchannel(:,:,3);d=allchannel(:,:,4);
d_C1(:,1)=a(:);d_C1(:,2)=b(:);d_C1(:,3)=c(:);d_C1(:,4)=d(:);
%%%%%%%%%%%%%%%%%%%%%%%%%central%%%%%%%%%%%%%%
[~,orderC]=sort(d_C1,2,'descend' ); 
LIOP_C = orderC(:,1)*1000 + orderC(:,2)*100 + orderC(:,3)*10+orderC(:,4);
 LIOP_C1 = mapping.table(LIOP_C)';





LIOP0=zeros(M*N,1);
LIOP2=zeros(M*N,1);
LIOP1=zeros(M*N,1);
LIOP3=zeros(M*N,1);


for i=1:P
     LIOP0=LIOP0+mLIOP(:,i)*2^(i-1);
       LIOP3=LIOP3+mLIOP3(:,i)*2^(i-1);
    LIOP2=LIOP2+mLIOP2(:,i)*2^(i-1);
     LIOP1=LIOP1+mLIOP1(:,i)*2^(i-1);

end

if  isstruct(LBPmapping)
     LIOP0=LBPmapping.table(LIOP0+1);
 LIOP1=LBPmapping.table(LIOP1+1);
LIOP3=LBPmapping.table(LIOP3+1);
LIOP2=LBPmapping.table(LIOP2+1);

 LBPbins=LBPmapping.num;
else

   LBPbins=256;
end
 

if(mode1 == 'h')
    
    
    LIOP_1= hist(LIOP0(:),1:LBPbins);     %%%%%CDS CDM histogram
LIOP_2= hist(LIOP1(:),1:LBPbins);
LIOP_4= hist(LIOP3(:),1:LBPbins);
LIOP_3= hist(LIOP2(:),1:LBPbins);
LIOP_C= hist(LIOP_C1(:),1:24);      %%%%central histogram

 result=[LIOP_1 LIOP_2 LIOP_3 LIOP_4 LIOP_C];
end





end

function [d_C,M,N,LIOP,ou,ou_sign]=getneighbor(allchannel,R,P,mapping)
 radius = R;
neighbors = P;

spoints =zeros(P,2);

% Angle step.
a1 = 2*pi/P;


%  C = allchannel(origy:origy+dy,origx:origx+dx,:);
% d_C = double(C);

   
for n=1:4
    d_image1=allchannel(:,:,n);
    for i= 1:P
    spoints(i,1) = -radius*sin((i-1)*a1);
    spoints(i,2) = radius*cos((i-1)*a1);
    end

    neighbors = size(spoints,1);

% Determine the dimensions of the input image.
[ysize xsize] = size(d_image1);



    miny=min(spoints(:,1));
    maxy=max(spoints(:,1));
    minx=min(spoints(:,2));
    maxx=max(spoints(:,2));

% Block size, each  code is computed within a block of size bsizey*bsizex
    bsizey=ceil(max(maxy,0))-floor(min(miny,0))+1;  
    bsizex=ceil(max(maxx,0))-floor(min(minx,0))+1;  

% Coordinates of origin (0,0) in the block
    origy=1-floor(min(miny,0));   
    origx=1-floor(min(minx,0));   


% Calculate dx and dy;
    dx = xsize - bsizex;
    dy = ysize - bsizey;


    C = allchannel(origy:origy+dy,origx:origx+dx,:);
    d_C = double(C);

  for i = 1:P
    y = spoints(i,1)+origy;
    x = spoints(i,2)+origx;
    % Calculate floors, ceils and rounds for the x and y.
    fy = floor(y); cy = ceil(y); ry = round(y);
    fx = floor(x); cx = ceil(x); rx = round(x);
    % Check if interpolation is needed.
    if (abs(x - rx) < 1e-6) && (abs(y - ry) < 1e-6)
        % Interpolation is not needed, use original datatypes
        N = d_image1(ry:ry+dy,rx:rx+dx);
        
        if (n==1)
        N1(:,i)=N(:);
        else if(n==2)
               N2(:,i)=N(:); 
            else if(n==3)
                N3(:,i)=N(:);
                else N4(:,i)=N(:);
                end
            end
        end
    else
        % Interpolation needed, use double type images
        ty = y - fy;
        tx = x - fx;
        % Calculate the interpolation weights.
        w1 = (1 - tx) * (1 - ty);
        w2 =      tx  * (1 - ty);
        w3 = (1 - tx) *      ty ;
        w4 =      tx  *      ty ;
        % Compute interpolated pixel values
        N = w1*d_image1(fy:fy+dy,fx:fx+dx) + w2*d_image1(fy:fy+dy,cx:cx+dx) + ...
            w3*d_image1(cy:cy+dy,fx:fx+dx) + w4*d_image1(cy:cy+dy,cx:cx+dx);
        if (n==1)
        N1(:,i)=N(:);
        else if(n==2)
               N2(:,i)=N(:); 
            else if(n==3)
                N3(:,i)=N(:);
                else N4(:,i)=N(:);
                end
            end
        end
    end 
end
end
[M,N]=size(N);

 ou_sign=zeros(M*N,P);
    LIOP=zeros(M*N,P);
    NN=zeros(M*N,4);
    ou=zeros(M*N,P);

d_C1=d_C(:,:,1);
d_C2=d_C(:,:,2);
d_C3=d_C(:,:,3);
d_C4=d_C(:,:,4);
d_C=[d_C1(:) d_C2(:) d_C3(:) d_C4(:)];
    for i=1:P
NN=[N1(:,i) N2(:,i) N3(:,i) N4(:,i)];
ou(:,i)=sqrt(sum(((NN-d_C).^2),2));         
sign1=sign(NN-d_C);
 ou_sign(:,i) = sign(sum(sign1,2));               


 [~,order]=sort(NN,2,'descend' ); 
LIOP(:,i) = mapping.table(order(:,1)*1000 + order(:,2)*100 + order(:,3)*10+order(:,4))';

    end
end

